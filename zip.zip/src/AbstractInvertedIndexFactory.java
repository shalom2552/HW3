
public abstract class AbstractInvertedIndexFactory {

    public abstract AbstractInvertedIndex createInvertedIndex();

}
